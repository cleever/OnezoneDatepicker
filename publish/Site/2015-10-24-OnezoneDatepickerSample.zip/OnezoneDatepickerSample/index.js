angular.module('ionicApp', ['ionic', 'onezone-datepicker'])

.config(function ($stateProvider, $urlRouterProvider) {
    $stateProvider
        .state('tabs', {
            url: "/tab",
            abstract: true,
            templateUrl: "templates/tabs.html"
        })
        .state('tabs.home', {
            url: "/home",
            views: {
                'home-tab': {
                    templateUrl: "templates/home.html",
                    controller: 'HomeTabCtrl'
                }
            }
        })
        .state('tabs.about', {
            url: "/about",
            views: {
                'about-tab': {
                    templateUrl: "templates/about.html"
                }
            }
        });

    $urlRouterProvider.otherwise("/tab/home");

})

.controller('HomeTabCtrl', function ($scope, $ionicModal) {
    var currentDate = new Date();
    var date = new Date(currentDate.getFullYear(), currentDate.getMonth(), 23);
    $scope.date = date;

    $scope.myFunction = function (date) {
        alert(date);
    };

    $scope.onezoneDatepicker = {
        date: date,
        mondayFirst: false,
        //months: ["Ianuarie", "Februarie", "Martie", "Aprilie", "Mai", "Iunie", "Iulie", "August", "Septembrie", "Octombrie", "Noiembrie", "Decembrie"],
        //daysOfTheWeek: ["Du", "Lu", "Ma", "Mi", "Jo", "Vi", "Sa"],
        startDate: new Date(1989, 1, 26),
        endDate: new Date(2024, 1, 26),
        disablePastDays: false,
        disableSwipe: false,
        disableWeekend: false,
        disableDates: [new Date(date.getFullYear(), date.getMonth(), 15), new Date(date.getFullYear(), date.getMonth(), 16), new Date(date.getFullYear(), date.getMonth(), 17)],
        showDatepicker: false,
        showTodayButton: true,
        calendarMode: false,
        hideCancelButton: false,
        hideSetButton: false,
        //callback: $scope.myFunction
    };

    $scope.showDatepicker = function () {
        $scope.onezoneDatepicker.showDatepicker = true;
    };
});